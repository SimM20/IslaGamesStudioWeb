beta1.6
╔════════════════╗
║    ECLIPSED FATES    ║
║    isla games dev    ║
╚════════════════╝


ENG:
Save path: C:\Users\user\AppData\LocalLow\Isla Games Studio\Eclipsed Fates
Recommended: delete save data if you change version.

console commands: 
1) help -for help.
2) clear -for clear the console.
3) kill -for killing the player.
4) quit -for leaving the game.
5) enable_level_light -for enable level light.
6) playmap_tutorial -to go to the tutorial.
7) playmap_level2 -to go to the map level2.
8) playmap_level3 -to go to the map level3.
9) playmap_level4 -to go to the map level4.
10) playmap_level5 -to go to the map level5.

*THE CONSOLE COMMANDS COULD CHANGE IN THE FINAL VERSION, NOT JUST BY CHANGING THEM BUT ADDING MORE AS WE THINK NECCESARY.


ESP:
Ruta de guardado de datos: C:\Users\user\AppData\LocalLow\Isla Games Studio\Eclipsed Fates
Recomendado: elimina los datos de guardado si cambias de versión.

Comandos de consola: 
1) help -para ayuda de comandos.
2) clear -para limpiar la consola.
3) kill -para matar al jugador.
4) quit -para salir del juego.
5) enable_level_light -para habilitar la luz del nivel.
6) playmap_tutorial -para ir al mapa tutorial.
7) playmap_level2 -para ir al mapa level2.
8) playmap_level3 -para ir al mapa level3.
9) playmap_level4 -para ir al mapa level4.
10) playmap_level5 -para ir al mapa level5.

*LOS COMANDOS DE LA CONSOLA PUEDEN VARIAR EN LA VERSION FINAL, NO SOLO CAMBIANDO LOS MISMOS SINO AGREGANDO MAS SEGUN SE CREA NECESARIO.

Isla Games Studio.